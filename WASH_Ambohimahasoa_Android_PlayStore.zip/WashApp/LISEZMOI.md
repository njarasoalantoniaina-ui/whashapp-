# WASH Ambohimahasoa – Application Android

Projet Android Studio (Kotlin + WebView). Votre code HTML est embarqué hors-ligne dans `app/src/main/assets/index.html`.
Les données (tâches, évaluations…) sont conservées sur le téléphone.

## Obtenir l'APK
**Option A – Android Studio** : File > Open > dossier du projet > attendre la synchronisation > Build > Build APK(s).
APK : `app/build/outputs/apk/debug/app-debug.apk`

**Option B – sans Android Studio (GitHub)** : créez un dépôt GitHub, envoyez tout ce dossier,
onglet *Actions* > « Build APK » > téléchargez l'artefact `WASH-Ambohimahasoa-apk`.

Installez ensuite l'APK sur le téléphone (autoriser les sources inconnues).

## Adaptations Android
- PDF : fenêtre d'impression Android > « Enregistrer au format PDF ».
- Excel / Word : fichier enregistré dans *Téléchargements* + menu de partage.
- Android 10 minimum (minSdk 29). Cible Android 16 (API 36).

**Play Store : voir `PLAY_STORE.md`.**
