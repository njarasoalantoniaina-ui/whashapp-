# Publier sur Google Play

Exigence actuelle de Google : nouvelles applications et mises à jour ciblent **Android 16 (API 36)** — c'est déjà configuré.

## 1. Compte développeur
Créez un compte sur play.google.com/console (frais uniques d'environ 25 USD). Un compte « personnel » récent peut devoir
faire un **test fermé avec ~12 testeurs pendant 14 jours** avant la production : vérifiez dans la Console.

## 2. Créer votre clé de signature (UNE SEULE FOIS – à sauvegarder précieusement !)
    keytool -genkeypair -v -keystore wash-release.jks -alias wash -keyalg RSA -keysize 2048 -validity 10000
Notez les mots de passe. **Si vous perdez ce fichier, vous ne pourrez plus mettre l'application à jour.** Ne le publiez jamais sur GitHub.

## 3. Générer le fichier .aab
**Option A – en local** : créez `keystore.properties` à la racine du projet :
    storeFile=/chemin/vers/wash-release.jks
    storePassword=VOTRE_MOT_DE_PASSE
    keyAlias=wash
    keyPassword=VOTRE_MOT_DE_PASSE
puis `gradle bundleRelease` (ou Android Studio : Build > Generate Signed Bundle).
Résultat : `app/build/outputs/bundle/release/app-release.aab`

**Option B – GitHub** : dans Settings > Secrets > Actions, ajoutez `KEYSTORE_BASE64` (le .jks encodé : `base64 -w0 wash-release.jks`),
`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Lancez « Build APK + AAB » et téléchargez l'AAB.

## 4. Fiche Play Store (dossier `store/`)
- Icône 512×512 : `store/icone_512x512.png`
- Image de présentation 1024×500 : `store/image_de_presentation_1024x500.png`
- Captures d'écran : au moins 2, prises sur votre téléphone.
- Nom : WASH Ambohimahasoa
- Description courte : Suivi quotidien des tâches EAH : pépinière, eau, blocs sanitaires.
- Description : Application de la Commune Urbaine d'Ambohimahasoa pour planifier et suivre les tâches journalières (calendrier, suivi et évaluation, planning annuel, plan de redressement, semis et mise en gaine) en français et en malagasy. Export PDF, Excel et Word. Fonctionne hors-ligne.
- Catégorie : Productivité (ou Outils) ; Gratuite.

## 5. Formulaires de la Console
- **Sécurité des données** : l'application ne collecte ni ne partage aucune donnée (tout reste sur le téléphone) et n'a aucune permission.
- **Politique de confidentialité** : URL publique obligatoire — hébergez `POLITIQUE_CONFIDENTIALITE.md` (GitHub Pages, par ex.).
- Classification du contenu, public cible (adultes), pas de publicité.

Pour chaque mise à jour : augmentez `versionCode` (+1) et `versionName` dans `app/build.gradle.kts`.
