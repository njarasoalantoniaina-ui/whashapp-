# Politique de confidentialité – WASH Ambohimahasoa

Dernière mise à jour : octobre 2026

L'application « WASH Ambohimahasoa » ne collecte, ne transmet et ne partage aucune donnée personnelle.
Les informations saisies (tâches, évaluations, plannings, listes de plantes) sont stockées uniquement sur l'appareil de l'utilisateur
et sont supprimées à la désinstallation de l'application.
L'application n'utilise ni compte, ni publicité, ni outil d'analyse, ni service tiers, et ne demande aucune autorisation sensible.
Les exports (PDF, Excel, Word) sont créés sur l'appareil ; leur partage éventuel relève du choix de l'utilisateur.

Contact : Rakotoarimanana Lantoniaina Njarasoa, ACEAH – Commune Urbaine d'Ambohimahasoa.
