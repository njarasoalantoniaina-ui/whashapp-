import java.util.Properties

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Clé de signature : fichier keystore.properties (local) OU variables d'environnement (GitHub)
val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun secret(k: String, env: String) = ksProps.getProperty(k) ?: System.getenv(env)

android {
    namespace = "mg.ambohimahasoa.wash"
    compileSdk = 36
    defaultConfig {
        applicationId = "mg.ambohimahasoa.wash"
        minSdk = 29; targetSdk = 36
        versionCode = 1; versionName = "1.0"
    }
    signingConfigs {
        create("release") {
            val path = secret("storeFile", "KEYSTORE_FILE")
            if (path != null) {
                storeFile = file(path)
                storePassword = secret("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = secret("keyAlias", "KEY_ALIAS")
                keyPassword = secret("keyPassword", "KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (secret("storeFile", "KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
